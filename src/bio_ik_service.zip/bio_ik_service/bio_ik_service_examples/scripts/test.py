#!/usr/bin/env python
from __future__ import print_function
import rospy

import bio_ik_msgs
import bio_ik_msgs.msg
import bio_ik_msgs.srv
import moveit_msgs.msg
import trajectory_msgs.msg
import numpy as np
import geometry_msgs.msg
from mainloop.msg import hand


rospy.init_node("bio_ik_service_example")






















print('---- proceed service ----')
rospy.wait_for_service("/bio_ik/get_bio_ik")
get_bio_ik = rospy.ServiceProxy("/bio_ik/get_bio_ik", bio_ik_msgs.srv.GetIK)

print('---- config request function ----')
request = bio_ik_msgs.msg.IKRequest()

request.group_name = "hand"

request.timeout.secs = 1

request.approximate = True

request.position_goals.append(bio_ik_msgs.msg.PositionGoal())
request.position_goals[-1].link_name = "if_3_b"
request.position_goals[-1].position.x = 0.03
request.position_goals[-1].position.y = 0.14
request.position_goals[-1].position.z = 0.01

request.position_goals.append(bio_ik_msgs.msg.PositionGoal())
request.position_goals[-1].link_name = "mf_3_b"
request.position_goals[-1].position.x = 0.01
request.position_goals[-1].position.y = 0.12
request.position_goals[-1].position.z = 0.01

request.pose_goals.append(bio_ik_msgs.msg.PoseGoal())
request.pose_goals[-1].link_name = "lf_3_b"
request.pose_goals[-1].pose.position.x = -0.028
request.pose_goals[-1].pose.position.y = 0.11
request.pose_goals[-1].pose.position.z = 0.012
request.pose_goals[-1].pose.orientation.x = 0.0
request.pose_goals[-1].pose.orientation.y = 0.0
request.pose_goals[-1].pose.orientation.z = 0.0
request.pose_goals[-1].pose.orientation.w = 1.0


#----------------------------------------------------------
if True:
    request.joint_variable_goals.append(bio_ik_msgs.msg.JointVariableGoal())
    request.joint_variable_goals[-1].variable_name = 'j_if_3_b'
    request.joint_variable_goals[-1].variable_position = -0.004
    request.joint_variable_goals[-1].weight = 1
    request.joint_variable_goals[-1].secondary = False
#----------------------------------------------------------

print('-'*50,' request ','-'*50)
print(request)

print('-'*50,' response with constraint -0.004 ','-'*50)

rospy.loginfo('before the ik calcu')
response = get_bio_ik(request).ik_response
rospy.loginfo('after the ik calcu')

print('name: ',response.solution.joint_state.name)
print('position: ',response.solution.joint_state.position)
print('position[9] and it len: ',response.solution.joint_state.position[9], len(response.solution.joint_state.position))
print('type of the position: ', type(response.solution.joint_state.position))
print('solution fitness: ',response.solution_fitness)
print('transforms: ',response.solution.multi_dof_joint_state.transforms)

#-------------------------------------------------------------
print('-'*25,' another response with constraint 0.004 ','-'*25)

if True:
    request.joint_variable_goals =  []
    request.joint_variable_goals.append(bio_ik_msgs.msg.JointVariableGoal())
    request.joint_variable_goals[-1].variable_name = 'j_if_3_b'
    request.joint_variable_goals[-1].variable_position = 0.004
    request.joint_variable_goals[-1].weight = 1
    request.joint_variable_goals[-1].secondary = False

response = get_bio_ik(request).ik_response

print('position: ',response.solution.joint_state.position)
print('position[9]: ',response.solution.joint_state.position[9])

#---------------------------------------------------------------

print('-'*50,' start display ','-'*50)
display = moveit_msgs.msg.DisplayTrajectory()
display.trajectory_start = response.solution
display.trajectory.append(moveit_msgs.msg.RobotTrajectory())
display.trajectory[0].joint_trajectory.points.append(trajectory_msgs.msg.JointTrajectoryPoint())
display.trajectory[0].joint_trajectory.points[-1].time_from_start.secs = 0
display.trajectory[0].joint_trajectory.points.append(trajectory_msgs.msg.JointTrajectoryPoint())
display.trajectory[0].joint_trajectory.points[-1].time_from_start.secs = 1
display_publisher = rospy.Publisher("/move_group/display_planned_path", moveit_msgs.msg.DisplayTrajectory, latch=True, queue_size=10)
display_publisher.publish(display)
rospy.spin()
