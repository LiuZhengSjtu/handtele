#!/usr/bin/env python
from __future__ import print_function
import rospy

import moveit_msgs.msg
import moveit_msgs.srv
import trajectory_msgs.msg
import geometry_msgs.msg
from moveit_msgs.msg import Constraints, OrientationConstraint, PositionConstraint,JointConstraint

print('---- start get_bio_in_hand.py ----')
print('---- init node ----')
rospy.init_node("bio_ik_service_example2")

rospy.wait_for_service("/bio_ik/get_position_ik")
get_position_ik = rospy.ServiceProxy("/bio_ik/get_position_ik", moveit_msgs.srv.GetPositionIK)

print('---- config request function ----')
request = moveit_msgs.msg.PositionIKRequest()

request.group_name = "hand"
# request.approximate
request.timeout.secs = 1

request.ik_link_names.append("if_3_b")
request.pose_stamped_vector.append(geometry_msgs.msg.PoseStamped())
request.pose_stamped_vector[-1].header.frame_id = "if_3_b"
request.pose_stamped_vector[-1].pose.position.x = 0.03
request.pose_stamped_vector[-1].pose.position.y = 0.13
request.pose_stamped_vector[-1].pose.position.z = 0.0
request.pose_stamped_vector[-1].pose.orientation.x = 0.0
request.pose_stamped_vector[-1].pose.orientation.y = 0.0
request.pose_stamped_vector[-1].pose.orientation.z = 0.0
request.pose_stamped_vector[-1].pose.orientation.w = 1.0

request.ik_link_names.append("mf_3_b")
request.pose_stamped_vector.append(geometry_msgs.msg.PoseStamped())
request.pose_stamped_vector[-1].header.frame_id = "if_3_b"
request.pose_stamped_vector[-1].pose.position.x = 0.01
request.pose_stamped_vector[-1].pose.position.y = 0.15
request.pose_stamped_vector[-1].pose.position.z = 0.0
request.pose_stamped_vector[-1].pose.orientation.x = 0.0
request.pose_stamped_vector[-1].pose.orientation.y = 0.0
request.pose_stamped_vector[-1].pose.orientation.z = 0.0
request.pose_stamped_vector[-1].pose.orientation.w = 1.0

request.ik_link_names.append("lf_3_b")
request.pose_stamped_vector.append(geometry_msgs.msg.PoseStamped())
request.pose_stamped_vector[-1].header.frame_id = "if_3_b"
request.pose_stamped_vector[-1].pose.position.x = -0.037
request.pose_stamped_vector[-1].pose.position.y = 0.12
request.pose_stamped_vector[-1].pose.position.z = 0.0
request.pose_stamped_vector[-1].pose.orientation.x = 0.0
request.pose_stamped_vector[-1].pose.orientation.y = 0.0
request.pose_stamped_vector[-1].pose.orientation.z = 0.0
request.pose_stamped_vector[-1].pose.orientation.w = 1.0



#----------------------------------------------------------
if True:
    rob_constraint = Constraints()
    rob_constraint.name = 'angle'

    joint_constraint = JointConstraint()
    joint_constraint.position = 0.1
    joint_constraint.tolerance_above = 0.02
    joint_constraint.tolerance_below = 0.02
    joint_constraint.weight = 0.1
    joint_constraint.joint_name = "j_rf_1_a"

    rob_constraint.joint_constraints.append(joint_constraint)
    request.constraints = rob_constraint
#----------------------------------------------------------


print('-'*50,' request ','-'*50)
print(request)
print('-'*50,' response ','-'*50)

response = get_position_ik(request)

print(response)

print('-'*50,' start display ','-'*50)

display = moveit_msgs.msg.DisplayTrajectory()
display.trajectory_start = response.solution
display.trajectory.append(moveit_msgs.msg.RobotTrajectory())
display.trajectory[0].joint_trajectory.points.append(trajectory_msgs.msg.JointTrajectoryPoint())
display.trajectory[0].joint_trajectory.points[-1].time_from_start.secs = 0
display.trajectory[0].joint_trajectory.points.append(trajectory_msgs.msg.JointTrajectoryPoint())
display.trajectory[0].joint_trajectory.points[-1].time_from_start.secs = 1
display_publisher = rospy.Publisher("/move_group/display_planned_path", moveit_msgs.msg.DisplayTrajectory, latch=True, queue_size=10)
display_publisher.publish(display)
rospy.spin()
